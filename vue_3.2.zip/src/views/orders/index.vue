<template>
  <div>orders</div>
</template>

<script setup></script>

<style lang="scss" scoped></style>
