<template>
  <div>reports</div>
</template>

<script setup></script>

<style lang="scss" scoped></style>
